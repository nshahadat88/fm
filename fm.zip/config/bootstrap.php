<?

/** Place for loading your config files **/

require_once (ROOT . DS . 'config' . DS . 'config.php');




