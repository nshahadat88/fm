<div id="page-header">
	<h1><?=$data['app_title'];?></h1>
	<p><a href="/">Home</a> | <a href="/about/">About</a></p>
</div>	