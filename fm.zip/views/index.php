<!DOCTYPE html>
<html lang="en">

<head>

	<?=$data['site_title'];?>
	<?=$data['meta_keywords'];?>
	<?=$data['meta_description'];?>
	<?=$data['site_icon'];?>
	<?=$data['css'];?>
	<?=$data['js'];?>

</head>
	
<body>

	<?=$data['header'];?>
	
	<div id="page-content">
	<?=$data['content'];?>
	</div>
	
	<?=$data['footer'];?>

</body>

</html>