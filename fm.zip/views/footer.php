<div id="page-footer">
	<p>	&copy 2013 <b><a href="http://www.oscarliang.net/">Oscar Liang</a></b>. All Rights Reserved.</p>	
</div>