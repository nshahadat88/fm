<form method="post" action="/">

	<input name="var1" type="text" style="width:50px;" />
	 
	 <div style="display:inline-block;">
	<input type="radio" name="operation" value="add" checked>+<br>
	<input type="radio" name="operation" value="sub">-
	</div>
	 
	 <input name="var2" type="text" style="width:50px;" />
	 
	 <input type="submit" name="submit" value="=" />

</form>


