<?php
//echo dirname(__FILE__).'<br>';

require_once (dirname(__FILE__) . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR . 'index.php');

