<?

class Model{

    function __construct() {
		// connect to database
		
    }

}